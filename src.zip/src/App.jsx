import './App.css'


function App() {

  return (
    <>
      
      <h1>Welcome to ReactJS world</h1>
      
      <div className='container'>
        <h3>React JS</h3>
        <p className='bg-warning'>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum maxime voluptatum numquam laboriosam reiciendis totam sunt deserunt amet expedita deleniti? A laborum incidunt aut officia maxime fuga? Vitae, minus libero.
        </p>
      </div>
    </>
  )
}

export default App
