import React from "react";

function Course(props)
{
    return(
        <>
        <br></br>
        <h2>
            Learn {props.title}
        </h2>
        </>
    );
}
export default Course;